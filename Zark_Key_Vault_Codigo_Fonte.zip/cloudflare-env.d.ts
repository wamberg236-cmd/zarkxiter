declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    APP_USERNAME?: string;
    APP_PASSWORD?: string;
    SESSION_SECRET?: string;
    INITIAL_KEYS_JSON?: string;
  }
}
