import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const licenseKeys = sqliteTable("license_keys", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  value: text("value").notNull().unique(),
  durationDays: integer("duration_days").notNull(),
  status: text("status", { enum: ["available", "used"] })
    .notNull()
    .default("available"),
  note: text("note"),
  createdAt: integer("created_at").notNull(),
  usedAt: integer("used_at"),
});

export type LicenseKey = typeof licenseKeys.$inferSelect;
