CREATE TABLE `license_keys` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`value` text NOT NULL,
	`duration_days` integer NOT NULL,
	`status` text DEFAULT 'available' NOT NULL,
	`note` text,
	`created_at` integer NOT NULL,
	`used_at` integer
);
--> statement-breakpoint
CREATE UNIQUE INDEX `license_keys_value_unique` ON `license_keys` (`value`);