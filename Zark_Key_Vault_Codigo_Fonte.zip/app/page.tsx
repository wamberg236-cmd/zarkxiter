import VaultClient from "./vault-client";

export const dynamic = "force-dynamic";

export default function Home() {
  return <VaultClient />;
}
