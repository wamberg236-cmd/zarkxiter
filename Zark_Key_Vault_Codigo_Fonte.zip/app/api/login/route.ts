import { NextResponse } from "next/server";
import { createSessionCookie, validateCredentials } from "../../lib/auth";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as
    | { username?: string; password?: string }
    | null;
  if (!body?.username || !body.password || !(await validateCredentials(body.username, body.password))) {
    return NextResponse.json({ error: "Login ou senha inválidos." }, { status: 401 });
  }
  const response = NextResponse.json({ ok: true });
  const cookie = await createSessionCookie();
  response.cookies.set(cookie.name, cookie.value, cookie.options);
  return response;
}
