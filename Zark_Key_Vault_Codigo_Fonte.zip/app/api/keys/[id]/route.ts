import { NextResponse } from "next/server";
import { isAuthenticated } from "../../../lib/auth";
import { removeKey, updateKeyStatus } from "../../../lib/key-service";

type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, context: Context) {
  if (!(await isAuthenticated())) return NextResponse.json({ error: "Não autorizado." }, { status: 401 });
  const { id: rawId } = await context.params;
  const id = Number(rawId);
  const body = (await request.json().catch(() => null)) as
    | { status?: "available" | "used" }
    | null;
  if (!Number.isInteger(id) || !body?.status || !["available", "used"].includes(body.status)) {
    return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
  }
  const key = await updateKeyStatus(id, body.status);
  if (!key) return NextResponse.json({ error: "Key não encontrada." }, { status: 404 });
  return NextResponse.json({ key });
}

export async function DELETE(_request: Request, context: Context) {
  if (!(await isAuthenticated())) return NextResponse.json({ error: "Não autorizado." }, { status: 401 });
  const { id: rawId } = await context.params;
  const id = Number(rawId);
  if (!Number.isInteger(id)) return NextResponse.json({ error: "ID inválido." }, { status: 400 });
  const key = await removeKey(id);
  if (!key) return NextResponse.json({ error: "Key não encontrada." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
