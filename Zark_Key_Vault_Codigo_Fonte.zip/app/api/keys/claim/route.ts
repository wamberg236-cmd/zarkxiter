import { NextResponse } from "next/server";
import { isAuthenticated } from "../../../lib/auth";
import { claimAvailableKey } from "../../../lib/key-service";

export async function POST(request: Request) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: "Não autorizado." }, { status: 401 });
  }

  const body = (await request.json().catch(() => null)) as
    | { durationDays?: number; note?: string }
    | null;

  if (!body?.durationDays || ![1, 7, 30].includes(body.durationDays)) {
    return NextResponse.json({ error: "Selecione uma validade válida." }, { status: 400 });
  }

  const key = await claimAvailableKey(body.durationDays, body.note);
  if (!key) {
    return NextResponse.json(
      { error: `Não há keys disponíveis de ${body.durationDays} dia${body.durationDays === 1 ? "" : "s"}.` },
      { status: 404 },
    );
  }

  return NextResponse.json({ key });
}
