import { NextResponse } from "next/server";
import { isAuthenticated } from "../../lib/auth";
import { addKey, listKeys } from "../../lib/key-service";

export async function GET() {
  if (!(await isAuthenticated())) return NextResponse.json({ error: "Não autorizado." }, { status: 401 });
  return NextResponse.json({ keys: await listKeys() });
}

export async function POST(request: Request) {
  if (!(await isAuthenticated())) return NextResponse.json({ error: "Não autorizado." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as
    | { value?: string; durationDays?: number; note?: string }
    | null;
  if (!body?.value || !body.durationDays || ![1, 7, 30].includes(body.durationDays)) {
    return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
  }
  try {
    return NextResponse.json({ key: await addKey(body.value, body.durationDays, body.note) }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Essa key já existe ou não pôde ser adicionada." }, { status: 409 });
  }
}
