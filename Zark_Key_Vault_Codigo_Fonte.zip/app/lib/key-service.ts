import "server-only";

import { env } from "cloudflare:workers";
import { and, asc, eq } from "drizzle-orm";
import { getDb } from "../../db";
import { licenseKeys } from "../../db/schema";

type InitialKey = { value: string; durationDays: number };

export async function ensureInitialKeys() {
  const raw = env.INITIAL_KEYS_JSON;
  if (!raw) return;
  let initialKeys: InitialKey[];
  try {
    initialKeys = JSON.parse(raw) as InitialKey[];
  } catch {
    throw new Error("INITIAL_KEYS_JSON inválido.");
  }
  const db = getDb();
  const now = Date.now();
  for (const item of initialKeys) {
    if (!item.value || ![1, 7, 30].includes(item.durationDays)) continue;
    await db.insert(licenseKeys).values({
      value: item.value.trim().toUpperCase(),
      durationDays: item.durationDays,
      status: "available",
      createdAt: now,
    }).onConflictDoNothing({ target: licenseKeys.value });
  }
}

export async function listKeys() {
  await ensureInitialKeys();
  return getDb().select().from(licenseKeys)
    .orderBy(asc(licenseKeys.durationDays), asc(licenseKeys.id));
}

export async function addKey(value: string, durationDays: number, note?: string) {
  const [created] = await getDb().insert(licenseKeys).values({
    value: value.trim().toUpperCase(), durationDays, status: "available",
    note: note?.trim() || null, createdAt: Date.now(),
  }).returning();
  return created;
}

export async function claimAvailableKey(durationDays: number, note?: string) {
  await ensureInitialKeys();
  const db = getDb();

  // The conditional update prevents the same key from being delivered twice
  // if two requests happen at nearly the same time.
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const [candidate] = await db.select().from(licenseKeys)
      .where(and(
        eq(licenseKeys.durationDays, durationDays),
        eq(licenseKeys.status, "available"),
      ))
      .orderBy(asc(licenseKeys.id))
      .limit(1);

    if (!candidate) return null;

    const [claimed] = await db.update(licenseKeys).set({
      status: "used",
      usedAt: Date.now(),
      note: note?.trim() || candidate.note,
    }).where(and(
      eq(licenseKeys.id, candidate.id),
      eq(licenseKeys.status, "available"),
    )).returning();

    if (claimed) return claimed;
  }

  return null;
}

export async function updateKeyStatus(id: number, status: "available" | "used") {
  const [updated] = await getDb().update(licenseKeys)
    .set({ status, usedAt: status === "used" ? Date.now() : null })
    .where(eq(licenseKeys.id, id)).returning();
  return updated;
}

export async function removeKey(id: number) {
  const [deleted] = await getDb().delete(licenseKeys)
    .where(eq(licenseKeys.id, id)).returning();
  return deleted;
}
