import "server-only";

import { env } from "cloudflare:workers";
import { cookies } from "next/headers";

const COOKIE_NAME = "zark_key_vault_session";
const MAX_AGE = 60 * 60 * 24 * 7;

function bytesToHex(bytes: ArrayBuffer) {
  return Array.from(new Uint8Array(bytes))
    .map((value) => value.toString(16).padStart(2, "0"))
    .join("");
}

async function sign(payload: string) {
  const secret = env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET não configurado.");
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return bytesToHex(
    await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload)),
  );
}

function constantTimeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let difference = 0;
  for (let index = 0; index < a.length; index += 1) {
    difference |= a.charCodeAt(index) ^ b.charCodeAt(index);
  }
  return difference === 0;
}

export async function validateCredentials(username: string, password: string) {
  return (
    constantTimeEqual(username, env.APP_USERNAME ?? "") &&
    constantTimeEqual(password, env.APP_PASSWORD ?? "")
  );
}

export async function createSessionCookie() {
  const expiresAt = Math.floor(Date.now() / 1000) + MAX_AGE;
  const payload = `${env.APP_USERNAME}:${expiresAt}`;
  const signature = await sign(payload);
  return {
    name: COOKIE_NAME,
    value: `${payload}.${signature}`,
    options: {
      httpOnly: true,
      secure: true,
      sameSite: "strict" as const,
      path: "/",
      maxAge: MAX_AGE,
    },
  };
}

export async function isAuthenticated() {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return false;
  const lastDot = token.lastIndexOf(".");
  if (lastDot < 0) return false;
  const payload = token.slice(0, lastDot);
  const suppliedSignature = token.slice(lastDot + 1);
  const [username, expiresAtRaw] = payload.split(":");
  const expiresAt = Number(expiresAtRaw);
  if (
    username !== env.APP_USERNAME ||
    !Number.isFinite(expiresAt) ||
    expiresAt < Math.floor(Date.now() / 1000)
  ) return false;
  const expectedSignature = await sign(payload);
  return constantTimeEqual(suppliedSignature, expectedSignature);
}

export const sessionCookieName = COOKIE_NAME;
