"use client";

import {
  Check, Clipboard, Eye, EyeOff, KeyRound, LockKeyhole, LogOut,
  Plus, Search, ShieldCheck, Trash2, X,
} from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";

type KeyRecord = {
  id: number;
  value: string;
  durationDays: number;
  status: "available" | "used";
  note: string | null;
  createdAt: number;
  usedAt: number | null;
};

const durationLabel: Record<number, string> = { 1: "1 dia", 7: "7 dias", 30: "30 dias" };
const maskedKey = (value: string) => value.replace(/[A-Z0-9]/g, "•");

export default function VaultClient() {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [keys, setKeys] = useState<KeyRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [query, setQuery] = useState("");
  const [duration, setDuration] = useState<"all" | 1 | 7 | 30>("all");
  const [status, setStatus] = useState<"all" | "available" | "used">("all");
  const [revealed, setRevealed] = useState<Set<number>>(new Set());
  const [copied, setCopied] = useState<number | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [showGenerate, setShowGenerate] = useState(false);
  const [generatedKey, setGeneratedKey] = useState<KeyRecord | null>(null);
  const [generating, setGenerating] = useState(false);
  const [generateError, setGenerateError] = useState("");

  async function loadKeys() {
    setLoading(true);
    const response = await fetch("/api/keys", { cache: "no-store" });
    if (response.status === 401) {
      setAuthenticated(false);
      setKeys([]);
    } else if (response.ok) {
      const data = (await response.json()) as { keys: KeyRecord[] };
      setKeys(data.keys);
      setAuthenticated(true);
    } else {
      setMessage("Não foi possível carregar as keys.");
    }
    setLoading(false);
  }

  useEffect(() => { void loadKeys(); }, []);

  const filtered = useMemo(() => {
    const normalized = query.trim().toUpperCase();
    return keys.filter((item) =>
      (duration === "all" || item.durationDays === duration) &&
      (status === "all" || item.status === status) &&
      (!normalized || item.value.includes(normalized) || item.note?.toUpperCase().includes(normalized)),
    );
  }, [keys, query, duration, status]);

  const availableCount = keys.filter((item) => item.status === "available").length;
  const usedCount = keys.length - availableCount;

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/login", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ username: form.get("username"), password: form.get("password") }),
    });
    if (!response.ok) {
      const data = (await response.json()) as { error?: string };
      setMessage(data.error ?? "Falha no login.");
      return;
    }
    await loadKeys();
  }

  async function handleLogout() {
    await fetch("/api/logout", { method: "POST" });
    setAuthenticated(false);
    setKeys([]);
  }

  async function copyKey(item: KeyRecord) {
    await navigator.clipboard.writeText(item.value);
    setCopied(item.id);
    window.setTimeout(() => setCopied(null), 1600);
  }

  async function toggleStatus(item: KeyRecord) {
    const nextStatus = item.status === "available" ? "used" : "available";
    const response = await fetch(`/api/keys/${item.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    });
    if (response.ok) await loadKeys();
  }

  async function deleteKey(item: KeyRecord) {
    if (!window.confirm("Excluir esta key permanentemente?")) return;
    const response = await fetch(`/api/keys/${item.id}`, { method: "DELETE" });
    if (response.ok) await loadKeys();
  }

  async function addNewKey(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/keys", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        value: form.get("value"),
        durationDays: Number(form.get("durationDays")),
        note: form.get("note"),
      }),
    });
    if (!response.ok) {
      const data = (await response.json()) as { error?: string };
      setMessage(data.error ?? "Não foi possível adicionar a key.");
      return;
    }
    event.currentTarget.reset();
    setShowAdd(false);
    setMessage("Key adicionada com sucesso.");
    await loadKeys();
  }

  async function generateKey(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setGenerating(true);
    setGenerateError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/keys/claim", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        durationDays: Number(form.get("durationDays")),
        note: form.get("note"),
      }),
    });
    const data = (await response.json()) as { key?: KeyRecord; error?: string };
    if (!response.ok || !data.key) {
      setGenerateError(data.error ?? "Não foi possível gerar a key.");
      setGenerating(false);
      return;
    }
    setGeneratedKey(data.key);
    setGenerating(false);
    await loadKeys();
  }

  function closeGenerate() {
    setShowGenerate(false);
    setGeneratedKey(null);
    setGenerateError("");
  }

  if (authenticated === null || loading) {
    return <main className="screen-center"><div className="loader" aria-label="Carregando" /></main>;
  }

  if (!authenticated) {
    return (
      <main className="login-shell">
        <section className="login-card">
          <div className="brand-mark"><LockKeyhole size={28} /></div>
          <p className="eyebrow">ACESSO RESTRITO</p>
          <h1>Zark Key Vault</h1>
          <p className="subtle">Entre para consultar e gerenciar suas keys com segurança.</p>
          <form onSubmit={handleLogin} className="login-form">
            <label>Login<input name="username" autoComplete="username" required /></label>
            <label>Senha<input name="password" type="password" autoComplete="current-password" required /></label>
            {message && <p className="error-message">{message}</p>}
            <button className="primary-button" type="submit"><ShieldCheck size={18} /> Entrar no painel</button>
          </form>
          <p className="security-note"><ShieldCheck size={14} /> Sessão protegida e keys armazenadas no servidor.</p>
        </section>
      </main>
    );
  }

  return (
    <main className="vault-shell">
      <header className="topbar">
        <div className="brand"><span className="brand-icon"><KeyRound size={22} /></span><div><strong>Zark Key Vault</strong><small>Painel privado de licenças</small></div></div>
        <div className="header-actions"><span className="secure-pill"><ShieldCheck size={15} /> Sessão protegida</span><button onClick={handleLogout} className="ghost-button"><LogOut size={17} /> Sair</button></div>
      </header>

      <section className="content">
        <div className="hero-row">
          <div><p className="eyebrow">GESTÃO CENTRALIZADA</p><h1>Suas keys, organizadas.</h1><p className="subtle">Consulte, copie e acompanhe o uso por período de validade.</p></div>
          <div className="hero-actions">
            <button className="secondary-button compact" onClick={() => setShowAdd(true)}><Plus size={18} /> Adicionar key</button>
            <button className="primary-button compact" onClick={() => setShowGenerate(true)}><KeyRound size={18} /> Gerar key</button>
          </div>
        </div>

        <section className="stats-grid">
          <article><span>Total</span><strong>{keys.length}</strong><small>keys cadastradas</small></article>
          <article className="available"><span>Disponíveis</span><strong>{availableCount}</strong><small>prontas para uso</small></article>
          <article className="used"><span>Utilizadas</span><strong>{usedCount}</strong><small>marcadas como usadas</small></article>
        </section>

        <section className="toolbar">
          <label className="search-box"><Search size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar key ou observação..." /></label>
          <div className="filter-row">
            {(["all", 1, 7, 30] as const).map((item) => <button key={item} onClick={() => setDuration(item)} className={duration === item ? "filter active" : "filter"}>{item === "all" ? "Todos os períodos" : durationLabel[item]}</button>)}
          </div>
          <select aria-label="Filtrar por status" value={status} onChange={(event) => setStatus(event.target.value as typeof status)}><option value="all">Todos os status</option><option value="available">Disponíveis</option><option value="used">Utilizadas</option></select>
        </section>

        {message && <div className="notice"><Check size={16} /> {message}<button onClick={() => setMessage("")}><X size={15} /></button></div>}

        <section className="key-list">
          <div className="table-heading"><span>Key</span><span>Validade</span><span>Status</span><span>Ações</span></div>
          {filtered.length === 0 ? <div className="empty-state"><KeyRound size={28} /><p>Nenhuma key encontrada.</p></div> : filtered.map((item) => (
            <article className={item.status === "used" ? "key-row is-used" : "key-row"} key={item.id}>
              <div className="key-value"><code>{revealed.has(item.id) ? item.value : maskedKey(item.value)}</code>{item.note && <small>{item.note}</small>}</div>
              <span className={`duration duration-${item.durationDays}`}>{durationLabel[item.durationDays]}</span>
              <button onClick={() => toggleStatus(item)} className={`status status-${item.status}`}>{item.status === "available" ? "Disponível" : "Utilizada"}</button>
              <div className="row-actions">
                <button title={revealed.has(item.id) ? "Ocultar" : "Revelar"} onClick={() => setRevealed((previous) => { const next = new Set(previous); next.has(item.id) ? next.delete(item.id) : next.add(item.id); return next; })}>{revealed.has(item.id) ? <EyeOff size={17} /> : <Eye size={17} />}</button>
                <button title="Copiar" onClick={() => copyKey(item)}>{copied === item.id ? <Check size={17} /> : <Clipboard size={17} />}</button>
                <button className="danger" title="Excluir" onClick={() => deleteKey(item)}><Trash2 size={17} /></button>
              </div>
            </article>
          ))}
        </section>
      </section>

      {showAdd && <div className="modal-backdrop" role="presentation" onMouseDown={() => setShowAdd(false)}><section className="modal" role="dialog" aria-modal="true" onMouseDown={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setShowAdd(false)}><X size={20} /></button><p className="eyebrow">NOVA LICENÇA</p><h2>Adicionar key</h2><form onSubmit={addNewKey}><label>Key<input name="value" placeholder="EXTERNAL-XXXX-XXXX-XXXX" required /></label><label>Validade<select name="durationDays" defaultValue="1"><option value="1">1 dia</option><option value="7">7 dias</option><option value="30">30 dias</option></select></label><label>Observação opcional<input name="note" placeholder="Cliente, pedido ou referência" /></label><button className="primary-button" type="submit"><Plus size={18} /> Salvar key</button></form></section></div>}
      {showGenerate && <div className="modal-backdrop" role="presentation" onMouseDown={closeGenerate}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="generate-title" onMouseDown={(event) => event.stopPropagation()}><button className="modal-close" onClick={closeGenerate}><X size={20} /></button><p className="eyebrow">ENTREGA AUTOMÁTICA</p><h2 id="generate-title">Gerar key</h2>{generatedKey ? <div className="generated-result"><span className={`duration duration-${generatedKey.durationDays}`}>{durationLabel[generatedKey.durationDays]}</span><p>Key retirada do banco e marcada como utilizada:</p><code>{generatedKey.value}</code><button className="primary-button" onClick={() => copyKey(generatedKey)}>{copied === generatedKey.id ? <Check size={18} /> : <Clipboard size={18} />} {copied === generatedKey.id ? "Copiada" : "Copiar key"}</button><button className="secondary-button" onClick={() => { setGeneratedKey(null); setGenerateError(""); }}>Gerar outra key</button></div> : <form onSubmit={generateKey}><label>Validade<select name="durationDays" defaultValue="1"><option value="1">1 dia</option><option value="7">7 dias</option><option value="30">30 dias</option></select></label><label>Cliente ou referência (opcional)<input name="note" placeholder="Ex.: Cliente João / Pedido 123" /></label>{generateError && <p className="error-message">{generateError}</p>}<p className="modal-help">Ao gerar, a próxima key disponível será retirada do banco e marcada como utilizada.</p><button className="primary-button" type="submit" disabled={generating}><KeyRound size={18} /> {generating ? "Buscando..." : "Buscar key disponível"}</button></form>}</section></div>}
    </main>
  );
}
